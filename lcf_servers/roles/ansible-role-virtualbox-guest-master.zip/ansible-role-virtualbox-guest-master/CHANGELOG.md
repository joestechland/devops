# Changelog


### [1.8.6](https://github.com/PeterMosmans/ansible-role-virtualbox-guest/compare/1.8.5...1.8.6) (2021-03-09)


### Bug Fixes

* fix incorrect indentation for stat module ([8cc74e2](https://github.com/PeterMosmans/ansible-role-virtualbox-guest/commit/8cc74e21a4cfcffc40e430bf9f792eff963a9038))

### [1.8.5](https://github.com/PeterMosmans/ansible-role-virtualbox-guest/compare/1.8.4...1.8.5) (2021-01-28)

### Features



### [1.8.4](https://github.com/PeterMosmans/ansible-role-virtualbox-guest/compare/v1.8.3...v1.8.4) (2020-08-03)


### Bug Fixes

* ensure that comparison of newly installed packages is correct ([8406900](https://github.com/PeterMosmans/ansible-role-virtualbox-guest/commit/8406900c1a378f1d03415ef160953cd95eb87615))

### [1.8.3](https://github.com/PeterMosmans/ansible-role-virtualbox-guest/compare/v1.8.2...v1.8.3) (2020-07-13)


### Bug Fixes

* remove commented code and whitespace ([dfc512f](https://github.com/PeterMosmans/ansible-role-virtualbox-guest/commit/dfc512fc697ebbf9fee4e7080ca7f26129a17e1e))

### 1.8.2 (2020-03-05)


### Bug Fixes

* properly remove leftover source ([2349a0d](https://github.com/PeterMosmans/ansible-role-virtualbox-guest/commit/2349a0df331fdda985c3b339fe79b1b5eb0128e8))

### 1.8.2 (2020-03-05)


### Bug Fixes

* properly remove leftover source ([2349a0d](https://github.com/PeterMosmans/ansible-role-virtualbox-guest/commit/2349a0df331fdda985c3b339fe79b1b5eb0128e8))
