[![Build Status](https://travis-ci.org/wtanaka/ansible-role-virtualbox.svg?branch=master)](https://travis-ci.org/wtanaka/ansible-role-virtualbox)
[![CircleCI](https://circleci.com/gh/wtanaka/ansible-role-virtualbox.svg?style=svg)](https://circleci.com/gh/wtanaka/ansible-role-virtualbox)

wtanaka.virtualbox
==================

Installs virtualbox

Example Playbook
----------------

    - hosts: servers
      roles:
         - wtanaka.virtualbox

License
-------

GPLv2

Author Information
------------------

http://wtanaka.com/
